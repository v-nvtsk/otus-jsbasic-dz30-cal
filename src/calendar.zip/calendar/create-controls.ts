import type { DateCallback } from "../api/calendar-api";
import { createElementFromHTML } from "../utils/create-element-from-html";

export function createControls(
  container: HTMLElement,
  date: Date | undefined,
  onMonthChange: DateCallback,
): HTMLElement {
  if (date === undefined) {
    date = new Date();
  }
  let controlsDate: Date = new Date(date.getFullYear(), date.getMonth(), 1);
  const controls = createElementFromHTML(`
  <div class="controls">
    <button class="controls__button controls__button--prev">&lt;&lt;</button>
    <button class="controls__button controls__button--next">&gt;&gt;</button>
    <button class="controls__button controls__button--today">Сегодня</button>
    <input type="text" class="controls__search" placeholder="search"/>
    <span class="controls__current-month">
      ${controlsDate.toLocaleDateString("ru", { month: "long", year: "numeric" })}
    </span>
  </div>
}`);
  container.prepend(controls[0] as HTMLElement);

  const btnPrev = container.querySelector(".controls__button--prev");
  const btnNext = container.querySelector(".controls__button--next");
  const btnToday = container.querySelector(".controls__button--today");

  btnPrev?.addEventListener("click", () => {
    controlsDate = new Date(controlsDate.getFullYear(), controlsDate.getMonth() - 1, 1);
    setControlsDate(container, controlsDate, onMonthChange);
  });

  btnNext?.addEventListener("click", () => {
    controlsDate = new Date(controlsDate.getFullYear(), controlsDate.getMonth() + 1, 1);
    setControlsDate(container, controlsDate, onMonthChange);
  });

  btnToday?.addEventListener("click", () => {
    controlsDate = new Date();
    setControlsDate(container, controlsDate, onMonthChange);
  });

  return container;
}

function setControlsDate(controls: HTMLElement, date: Date, onMonthChange: DateCallback): void {
  const controlsDate: Date = new Date(date.getFullYear(), date.getMonth(), 1);
  const currentMonth = controls.querySelector(".controls__current-month");
  if (currentMonth === null) {
    return;
  }
  currentMonth.textContent = controlsDate.toLocaleDateString("ru", {
    month: "long",
    year: "numeric",
  });
  onMonthChange(controlsDate);
}

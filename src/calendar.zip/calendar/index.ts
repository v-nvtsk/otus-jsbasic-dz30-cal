import "./style.css";
import { Calendar } from "./calendar.old";

// import { read } from "../api/read";
// import { update } from "../api/update";
// import { type ITodoItem } from "./lib";

/* 

read()
  .then((res) => {
    console.log(res);
    return res;
  })
  .then(async (res) => {
    // console.log("res: ", res);
    if (!Array.isArray(res)) return;
    const item = res[0] as ITodoItem;
    console.log("item: ", item);
    item.todo = "Just do it!!!";
    await update(item);
  })
  .then(async () => {
    return await read();
  })
  .then((res) => {
    console.log(res);
    return res;
  })
  .catch((e) => {
    console.error(e);
  });

 */

export { Calendar };

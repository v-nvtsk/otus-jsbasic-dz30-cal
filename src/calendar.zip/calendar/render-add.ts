import { createElementFromHTML } from "../utils/create-element-from-html";

export async function renderAdd(parent: HTMLElement): Promise<HTMLCollection> {
  const modal = createElementFromHTML(`
    <dialog class="modal">
      <div class="btn-close-task">X</div>
      <p class="title">Add task</p>
      <textarea class="input"></textarea>
      <button class="btn-add-task">Add task</button>
      <button class="btn-cancel">Cancel</button>
  `);
  parent.append(modal[0]);

  document.addEventListener("keydown", handleEscape.bind(null, modal[0]));

  modal[0].addEventListener("close", (e) => {
    document.removeEventListener("keydown", handleEscape.bind(null, modal[0]));
  });
  return modal;
}

function handleEscape(modal: Element, ev: KeyboardEvent): void {
  if (ev.key === "Escape") {
    (modal as HTMLDialogElement).close();
    document.body.removeChild(modal);
  }
}

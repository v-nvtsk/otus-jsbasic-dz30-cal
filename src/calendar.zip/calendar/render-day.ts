import { type TodoItem } from "../api/calendar-api";
import { createElementFromHTML } from "../utils/create-element-from-html";

export function renderDay(container: HTMLElement, date: Date, tasks?: any): HTMLElement {
  const hours = [];
  const dateListEl = document.createElement("div");
  dateListEl.className = "date-list";

  const dateHours = new Date(date);

  const taskData = Array.from({ length: 24 }, () => ({ todo: "", id: "", date: new Date() })) as TodoItem[];
  if (tasks !== undefined)
    tasks.forEach((task: TodoItem) => {
      taskData[task.date.getHours()] = task;
    });

  for (let i = 0; i < 24; i += 1) {
    dateHours.setHours(i, 0, 0, 0);
    const id = taskData[i] !== undefined ? 'data-id="' + taskData[i]?.id + '"' : "";
    const hour = createElementFromHTML(`
    <div class="hour" data-date="${dateHours.valueOf()}" ${id}>
      <span class="hour__value">${i}:00</span>
      <span class="hour__todo">${taskData[i].todo}</span>
      <span class="hour__remove">🗑️</span>
    </div>
    `);
    hours.push(hour);
    dateListEl.append(hour[0]);
  }
  container.append(dateListEl);

  return container;
}

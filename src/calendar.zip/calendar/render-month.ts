import { type TodoItem } from "../api/calendar-api";
import { createElementFromHTML } from "../utils/create-element-from-html";

function daysInMonth(month: number, year: number): number {
  return new Date(year, month, 0).getDate();
}

export function renderMonth(container: HTMLElement, date: Date, tasks?: any): HTMLElement {
  const monthNum = date.getMonth() + 1;
  const month = [];
  const monthEl = document.createElement("div");
  monthEl.className = "month";

  const monthLength = daysInMonth(monthNum, date.getFullYear());

  const taskData = Array.from({ length: monthLength }, () => 0);
  if (tasks !== undefined)
    tasks.forEach((task: TodoItem) => {
      taskData[task.date.getDate() - 1] += 1;
    });

  for (let i = 1; i <= monthLength; i += 1) {
    const currentElementDate = new Date(date.getFullYear(), date.getMonth(), i);
    const dateEl = createElementFromHTML(`
    <div class="date" data-date="${currentElementDate.valueOf()}" data-tasks="${taskData[i - 1]}">
      <span class="date__value">${i}</span>
      ${taskData[i - 1] !== 0 ? `<span class="date__todo">(${taskData[i - 1]})</span>` : ""}
    </div>
    `);
    month.push(dateEl);
    monthEl.append(dateEl[0]);
  }
  container.append(monthEl);
  return container;
}

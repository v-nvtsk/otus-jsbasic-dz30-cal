import type { CalendarAPI, Filter, TodoItem } from "../api/calendar-api";
import { Firebase } from "../api/firebase";
import { createControls } from "./create-controls";
import { LocalStore } from "../api/local-storage";
import { renderDay } from "./render-day";
import { renderMonth } from "./render-month";
import { createElement } from "../utils/create-element";
import { createElementFromHTML } from "../utils/create-element-from-html";

export class Calendar {
  private readonly calendar: HTMLElement;
  private readonly content: HTMLElement;
  private activeDate: Date;
  // private readonly lStorage = new LocalStore();
  constructor(
    private readonly root: HTMLElement,
    private readonly store: CalendarAPI = new Firebase(),
  ) {
    const calendar = createElementFromHTML(`<div class="calendar"></div>`)[0] as HTMLElement;
    this.calendar = calendar;
    this.activeDate = new Date();
    this.content = createElementFromHTML(`<div class="content"></div>`)[0] as HTMLElement;
    this.calendar.append(this.content);
  }

  public init(): void {
    this.root.append(this.calendar);
    createControls(this.calendar, new Date(), this.onMonthChange.bind(this));
    // renderMonth(this.content, new Date());
    this.onMonthChange(new Date());
    this.calendar.addEventListener("click", this.clickHandler.bind(this), {
      capture: true,
    });
  }

  private clickHandler(ev: MouseEvent): void {
    const target = ev.target as HTMLElement;

    if (target.dataset?.date !== undefined) {
      const returnDate = new Date(Number(target.dataset.date));

      if (target.className === "hour") {
        this.onHourSelect(target, returnDate);
      } else if (target.className === "date") {
        this.onDaySelect(returnDate);
      }
    } else if (target.className === "hour__remove") {
      if (target.parentElement?.dataset?.id !== undefined) {
        this.onRemove(target.parentElement.dataset.id)
          .then((res) => {
            if (target.parentElement !== null) {
              const todoEl = target.parentElement.querySelector(".hour__todo");
              if (todoEl !== null) {
                todoEl.innerHTML = "";
                target.parentElement.dataset.id = "";
              }
            }
          })
          .catch((e) => {
            // eslint-disable-next-line no-console
            console.error(e);
          });
      }
    }
  }

  private async onRemove(id: string): Promise<void> {
    await this.delete(id);
  }

  private onMonthChange(date: Date): void {
    this.activeDate = date;
    this.content.innerHTML = "";
    const filter: Partial<Filter> = {
      year: date.getFullYear(),
      month: date.getMonth(),
    };

    // findRecordsForMonth(date)
    this.read(filter)
      .then((res) => {
        renderMonth(this.content, date, res);
      })
      .catch((e) => {
        // eslint-disable-next-line no-console
        console.error(e);
      });
  }

  private onDaySelect(date: Date): void {
    this.activeDate = date;
    this.content.innerHTML = "";

    this.read({ year: date.getFullYear(), month: date.getMonth(), day: date.getDate() })
      // findRecordsForDate(date)
      .then((res) => {
        renderDay(this.content, date, res);
      })
      .catch((e) => {
        // eslint-disable-next-line no-console
        console.error(e);
      });
  }

  private onHourSelect(target: HTMLElement, date: Date): void {
    this.activeDate = date;
    // this.save(target);
    this.showTaskModal(target);
  }

  private showTaskModal(target: HTMLElement): HTMLDialogElement {
    const modal = createElement({ tag: "dialog", className: "modal" }) as HTMLDialogElement;
    modal.append(createElement({ tag: "p", className: "title", innerHTML: "Add task" }));
    const inputEl = createElement({ tag: "textarea", className: "input", innerHTML: "" }) as HTMLInputElement;
    const modalState = "add";

    modal.append(inputEl);
    let returnValue = "";
    const addTaskBtn = createElement({
      tag: "button",
      className: "btn-add-task",
      innerHTML: "Add task",
    }) as HTMLButtonElement;
    addTaskBtn.type = "submit";
    modal.append(addTaskBtn);

    modal.addEventListener("close", (e) => {
      const todoEl = target.querySelector(".hour__todo");
      if (todoEl !== null && returnValue !== "") todoEl.innerHTML = returnValue;
      document.removeEventListener("keydown", handleEscape);
    });

    const handleEscape = (ev: KeyboardEvent): void => {
      if (ev.key === "Escape") {
        modal.close();
        document.body.removeChild(modal);
        document.removeEventListener("keydown", handleEscape);
      }
    };
    document.addEventListener("keydown", handleEscape);

    addTaskBtn.addEventListener("click", () => {
      const todo = inputEl?.value;
      if (todo === "") {
        return;
      }
      // modal.returnValue = todo;
      let alterPromise: Promise<TodoItem | string | undefined>;
      if (modalState === "add") {
        alterPromise = this.create({
          date: this.activeDate,
          todo,
        });
      } else {
        alterPromise = this.update({
          id: target.dataset.id,
          date: this.activeDate,
          todo,
        });
      }
      alterPromise
        .then((id) => {
          if (id !== undefined && typeof id === "string") {
            target.dataset.id = id;
            returnValue = todo;
            modal.close();
            document.body.removeChild(modal);
          }
        })
        .catch((err: Error) => {
          // eslint-disable-next-line no-console
          console.error(err);
        });
    });
    document.body.append(modal);
    const contentEl = target.querySelector(".hour__todo");
    if (contentEl !== null && contentEl?.innerHTML !== "") {
      addTaskBtn.innerHTML = "Update task";
      inputEl.value = contentEl.innerHTML;
    }
    modal.showModal();
    return modal;
  }

  private async create(data: TodoItem): Promise<string | undefined> {
    const result = await this.store.create(data);
    return result;
  }

  private async read(filter: Partial<Filter>): Promise<TodoItem[]> {
    const result = await this.store.read(filter);
    return result;
  }

  private async update(data: Partial<TodoItem>): Promise<TodoItem | undefined> {
    const result = await this.store.update(data);
    return result;
  }

  private async delete(id: string): Promise<void> {
    await this.store.delete(id);
  }
}

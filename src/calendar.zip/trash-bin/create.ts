// import { type TodoItem } from "./calendar-api";
// import { db } from "./firebase";
// import { addDoc, collection } from "firebase/firestore";

// export async function create(data: TodoItem): Promise<string | undefined> {
//   try {
//     const response = await addDoc(collection(db, "calendar"), data);
//     return response.id;
//   } catch (e: any) {
//     if (e instanceof Error) throw new Error("firebase read error: ", e);
//   }
// }

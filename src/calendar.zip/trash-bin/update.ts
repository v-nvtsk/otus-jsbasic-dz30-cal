// import { doc, updateDoc } from "firebase/firestore";
// import { type TodoItem } from "./calendar-api";
// import { db } from "./firebase";

// export async function update(item: TodoItem): Promise<void> {
//   if (item.id === undefined) return;
//   const docRef = doc(db, "calendar", item.id);

//   await updateDoc(docRef, { todo: item.todo });
// }

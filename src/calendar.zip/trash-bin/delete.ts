// import { db } from "./firebase";
// import { doc, deleteDoc } from "firebase/firestore";
// import { read } from "./read";

// export async function deleteItem(id: string): Promise<void> {
//   await read();
//   await deleteDoc(doc(db, "calendar", id));
// }

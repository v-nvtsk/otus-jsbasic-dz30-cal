// interface ITodoItem {
//   date: number;
//   todo: string;
// }

// interface IFilter {
//   year: number;
//   month: number;
//   day: number;
//   hour: number;
//   date: number;
// }

// export interface ICRUD {
//   create: (data: ITodoItem) => Promise<string | undefined>;
//   read: (filter: Partial<IFilter>) => Promise<ITodoItem[]>;
//   update: (data: ITodoItem) => Promise<void>;
//   delete: (date: number) => Promise<void>;
// }

// export class Store implements ICRUD {
//   private readonly store: ITodoItem[];
//   constructor() {
//     this.store = [];
//   }

//   async create(data: ITodoItem): Promise<string | undefined> {
//     return await new Promise((resolve, reject) => {
//       if (data?.date === undefined || data?.todo === undefined) {
//         reject(new Error("Empty data"));
//       }
//       const date = new Date(data.date);

//       this.read({
//         year: date?.getFullYear(),
//         month: date?.getMonth(),
//         day: date?.getDate(),
//         hour: date?.getHours(),
//       })
//         .then((res) => {
//           if (res.length > 0) reject(new Error("Already exist"));
//           const id = Date.now().toString();
//           this.store.push(data);
//           resolve(id);
//         })
//         .catch((e) => {
//           console.error(e);
//         });
//     });
//   }

//   async read(filter: Partial<IFilter>): Promise<ITodoItem[]> {
//     return await new Promise((resolve) => {
//       const result = this.store.filter((el: ITodoItem) => {
//         const date = new Date(el.date);
//         if (filter.year !== null && filter.year !== date.getFullYear()) return false;
//         if (filter.month !== null && filter.month !== date.getMonth()) return false;
//         if (filter.day !== null && filter.day !== date.getDate()) return false;
//         if (filter.hour !== null && filter.hour !== date.getHours()) return false;
//         if (filter.date !== null && filter.date !== date.getTime()) return false;
//         return el;
//       });
//       resolve(result);
//     });
//   }

//   async update(data: ITodoItem): Promise<void> {}
//   async delete(id: number): Promise<void> {}
// }

// import { type TodoItem } from "./calendar-api";
// import { db } from "./firebase";
// import { collection, getDocs, orderBy, query, where } from "firebase/firestore";

// export async function read(): Promise<any[]> {
//   try {
//     const response = await getDocs(collection(db, "calendar"));
//     const newData = response.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
//     return newData;
//   } catch (e) {
//     console.log("firebase read error: ", e);
//     return [];
//   }
// }

// export async function findAllRecords(): Promise<any[]> {
//   try {
//     const response = await getDocs(collection(db, "calendar"));
//     const newData = response.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
//     return newData;
//   } catch (e) {
//     console.log("firebase read error: ", e);
//     return [];
//   }
// }

// export async function findRecordsForMonth(date: Date): Promise<TodoItem[]> {
//   try {
//     const monthStart = new Date(date.getFullYear(), date.getMonth(), 1);
//     const monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 1);
//     const q = query(
//       collection(db, "calendar"),
//       where("date", ">=", monthStart),
//       where("date", "<", monthEnd),
//       orderBy("date"),
//     );
//     const querySnapshot = await getDocs(q);
//     return querySnapshot.docs.map((doc) => {
//       // doc.data() is never undefined for query doc snapshots
//       const docData = doc.data();
//       const task: TodoItem = {
//         id: doc.id,
//         date: docData.date.toDate(),
//         todo: docData.todo,
//       };
//       return task;
//     });
//   } catch (e) {
//     console.log(e);
//     return [];
//   }
// }

// export async function findRecordsForDate(date: Date): Promise<TodoItem[]> {
//   try {
//     const dayStart = new Date(date.getFullYear(), date.getMonth(), date.getDate());
//     const dayEnd = new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1);
//     const q = query(
//       collection(db, "calendar"),
//       where("date", ">=", dayStart),
//       where("date", "<", dayEnd),
//       orderBy("date"),
//     );
//     const querySnapshot = await getDocs(q);
//     return querySnapshot.docs.map((doc) => {
//       // doc.data() is never undefined for query doc snapshots
//       const docData = doc.data();
//       const task: TodoItem = {
//         id: doc.id,
//         date: docData.date.toDate(),
//         todo: docData.todo,
//       };
//       return task;
//     }, []);
//   } catch (e) {
//     console.error(e);
//     return [];
//   }
// }
